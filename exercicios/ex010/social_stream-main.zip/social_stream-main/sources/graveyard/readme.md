Here be the the lost souls of streaming sites past.

~ Code never dies; it will live on forever with us as an AMI image you refuse to delete



### Icons

I do not claim rights of all the icons/logos distributed. While I (or other contributors) made some of the icons, trademarks and logos of third party companies/services are the rights of those respectivitive entities. Use them according to the terms that those entities may offer them under.

The main readme.md may contain additional attributions.