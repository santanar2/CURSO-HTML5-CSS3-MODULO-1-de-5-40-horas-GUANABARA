These two overlays are based on sampleapi.html, with modifications made with the help of Claude and ChatGPT

Code changes contributed by @DEKU_QCK

[code for version 1](https://github.com/steveseguin/social_stream/blob/main/themes/deuks_overlay/overlay1.html) - [https://socialstream.ninja/themes/deuks_overlay/overlay1.html](https://socialstream.ninja/themes/deuks_overlay/overlay1.html)

![image](https://github.com/user-attachments/assets/fd21a2a5-ef90-47ad-b396-071f78ab6f65)

[code for version 2 ](https://github.com/steveseguin/social_stream/blob/main/themes/deuks_overlay/overlay2.html)(twitch/tiktok specific)  - [https://socialstream.ninja/themes/deuks_overlay/overlay2.html](https://socialstream.ninja/themes/deuks_overlay/overlay2.html)

![image](https://github.com/user-attachments/assets/cde12b7a-8d5c-43a7-81f7-8173aabd2c8f)
