usage:

`https://socialstream.ninja/themes/Windows3.1/index.html?session=XXXXXX`

replace XXXXXX with your session ID.

![image](https://github.com/user-attachments/assets/8718a659-6ecb-43ff-a3ae-ff41a506cad3)


